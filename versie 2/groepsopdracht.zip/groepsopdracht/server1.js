const express = require('express');
const mysql = require('mysql2');
const bodyParser = require('body-parser');
const app = express();
const port = 3000;

app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static('public'));

const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: '',
  database: 'bevolkingsregister'
});

db.connect(err => {
  if (err) throw err;
  console.log('Verbonden met MySQL');
});

// ✅ Ophalen van burgergegevens
app.get('/haal-burger-op/:id', (req, res) => {
  const burgerId = req.params.id;
  const sql = 'SELECT * FROM burger WHERE id = ?';
  db.query(sql, [burgerId], (err, results) => {
    if (err) {
      console.error('Fout bij ophalen:', err);
      res.status(500).send('Ophalen mislukt');
    } else if (results.length === 0) {
      res.status(404).send('Burger niet gevonden');
    } else {
      res.json(results[0]);
    }
  });
});

// ✅ Wijzigen van burgergegevens
app.post('/wijzig-burger', (req, res) => {
  const {
    burger_id,
    voornaam,
    achternaam,
    geslacht,
    adres,
    email,
    geboortedatum,
    burgerlijke_staat
  } = req.body;

  const sql = `UPDATE burger SET 
    voornaam = ?, achternaam = ?, geslacht = ?, adres = ?, email = ?, geboortedatum = ?, burgerlijke_staat = ?
    WHERE id = ?`;

  db.query(sql, [
    voornaam,
    achternaam,
    geslacht,
    adres,
    email,
    geboortedatum,
    burgerlijke_staat,
    burger_id
  ], (err, result) => {
    if (err) {
      console.error('Fout bij wijzigen:', err);
      res.status(500).send('Wijziging mislukt');
    } else {
      res.send('Burgergegevens succesvol gewijzigd!');
    }
  });
});

app.listen(port, () => {
  console.log(`Server draait op http://localhost:${port}`);
});